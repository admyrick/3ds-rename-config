
 WildRename v2.15
 written by Kostas Symeonidis
 (c)1997-2008 CyLog Software, All Rights Reserved
-------------------------------------------------------------------------------

 WildRename is a multi-file renaming application for Microsoft Windows users.
 Its very simple user interface helps you build and perform many file
 renaming operations one-by-one or in batches.

 For more details, please read the program documentation accessible through
 the program's main menu.

 * Installation
   Just unzip the file you downloaded and copy it to a folder of your choice.

 * Un-Install
   Go to the folder you have copied the executable and delete the executable
   (*.exe) and any other files (*.ini, *.xml) that have been created
   when you first run the program. This utility DOES NOT write anywhere else
   on your disk NOR the windows registry.

-------------------------------------------------------------------------------
 CyLog Software - License Agreement

 License
 CyLog Software grants you a nonexclusive license to use the accompanying
 copyrighted software program (the Software), which includes any associated
 software components, and any online or electronic documentation, subject to
 the terms and restrictions set forth in this License Agreement. By installing,
 copying, or otherwise using the Software, you agree to be bound by the terms
 of this License Agreement. You are not permitted to lease, rent, distribute
 or sublicense the Software or to use the Software in a time-sharing
 arrangement or in any other unauthorized manner. Further, no license is
 granted to you in the human readable code of the Software (source code).
 Except as provided below, this License Agreement does not grant you any rights
 to patents, copyrights, trade secrets, trademarks, or any other rights in
 respect to the Software.

 Restrictions
 Modification, reverse engineering, reverse compiling, or disassembly of the
 Software is expressly prohibited, except and only to the extent that such
 activity is expressly permitted by applicable law.

 No Warranty
 The software and documentation are provided on an "as is" basis and all risk
 as to the quality and performance of the software is with you. Because the
 software is licensed free of charge, CyLog Software makes no warranties,
 express, implied or statutory, as to any matter whatsoever. In particular, any
 and all warranties of merchantability, fitness for a particular purpose or
 non-infringement of third parties rights are expressly excluded. Further,
 CyLog Software makes no representations or warranties that the software and
 documentation provided are free of errors or viruses or that the software and
 documentation are suitable for your intended use.

 Limitation of Liability
 In no event shall the author or CyLog Software be liable to you or any other
 party for any incidental, special or consequential damages, loss of data or
 data being rendered inaccurate, loss of profits or revenue, or interruption
 of business in any way arising out of or related to the use or inability to
 use the software and/or documentation, regardless of the form of action,
 whether in contract, tort (including negligence), strict product liability or
 otherwise, even if any representative of the author or CyLog Software has been
 advised of the possibility of such damages. This disclaimer of liability for
 damages will not be affected by any failure of the sole and exclusive remedies
 hereunder.

 Should you have any questions concerning this License Agreement, or if you
 desire to contact CyLog Software for any reason, please contact us by using
 our on-line contact form at: http://www.cylog.org/contactus.asp


